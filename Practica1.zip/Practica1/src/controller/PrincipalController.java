package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import model.Usuario;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class PrincipalController implements Initializable {
    @FXML
    private MenuBar menuBar;
    @FXML
    private TableView<Usuario> tableView;

    public void clickMenuArchivoCerrar(ActionEvent actionEvent) {
        Scene escena = menuBar.getScene();
        Stage stage = (Stage) escena.getWindow();
        stage.close();
    }

    public void clickMenuRegistroUsuario(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/registroUsuario.fxml"));
        Stage stage = new Stage();
        stage.setTitle("Formulario de Registro");
        stage.setScene(new Scene(root, 640, 480));
        stage.show();
    }

    public void clickBtnBorrar(ActionEvent actionEvent){
        int posicionUsuario = tableView.getSelectionModel().getSelectedIndex();
        tableView.getItems().remove(posicionUsuario);
    }

    public void clickBtnAgregar(ActionEvent actionEvent){
        int posicionUsuario = tableView.getSelectionModel().getSelectedIndex();
        tableView.getItems().add(new Usuario("", "", "","","", "", "", "", ""));
    }

    public void clickMenuAyudaAbout(ActionEvent actionEvent) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle("Acerca de");
        alerta.setHeaderText("Derechos Reservados");
        alerta.setContentText("Made in SUFFER\nAlejandro Ibarra Ramos\n" +
                "Miguel Arturo Guzmán Gómez\nDracko Ulises Valdez Burgueño");
        alerta.show();
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        tableView.setPlaceholder(new Label("Sin alumnos registrados"));
        // Crear columnas
        TableColumn<Usuario, String> columna1 = new TableColumn<>("Nombre");
        TableColumn<Usuario, String> columna2 = new TableColumn<>("Apellido Paterno");
        TableColumn<Usuario, String> columna3 = new TableColumn<>("Apellido Materno");
        TableColumn<Usuario, String> columna4 = new TableColumn<>("Domicilio");
        TableColumn<Usuario, String> columna5 = new TableColumn<>("Genero");
        TableColumn<Usuario, String> columna6 = new TableColumn<>("CURP");
        TableColumn<Usuario, String> columna7 = new TableColumn<>("No. Control");
        TableColumn<Usuario, String> columna8 = new TableColumn<>("Correo Electrónico");
        TableColumn<Usuario, String> columna9 = new TableColumn<>("Celular");

        // Indicar a cada columna de donde va a obtener la informacion a mostrar
        columna1.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        columna2.setCellValueFactory(new PropertyValueFactory<>("apellidoP"));
        columna3.setCellValueFactory(new PropertyValueFactory<>("apellidoM"));
        columna4.setCellValueFactory(new PropertyValueFactory<>("domicilio"));
        columna5.setCellValueFactory(new PropertyValueFactory<>("genero"));
        columna6.setCellValueFactory(new PropertyValueFactory<>("curp"));
        columna7.setCellValueFactory(new PropertyValueFactory<>("numeroControl"));
        columna8.setCellValueFactory(new PropertyValueFactory<>("correo"));
        columna9.setCellValueFactory(new PropertyValueFactory<>("celular"));


        // Edit
        tableView.setEditable(true);
        columna1.setCellFactory(TextFieldTableCell.forTableColumn());
        columna1.setOnEditCommit(evento -> {
            String nuevoNombre = evento.getNewValue();
            int posicionUsuario = evento.getTablePosition().getRow();
            evento.getTableView().getItems().get(posicionUsuario).setNombre(nuevoNombre);
        });

        columna2.setCellFactory(TextFieldTableCell.forTableColumn());
        columna2.setOnEditCommit(evento -> {
            String nuevoApellidoP = evento.getNewValue();
            int posicionUsuario = evento.getTablePosition().getRow();
            evento.getTableView().getItems().get(posicionUsuario).setApellidoP(nuevoApellidoP);
        });

        columna3.setCellFactory(TextFieldTableCell.forTableColumn());
        columna3.setOnEditCommit(evento -> {
            String nuevoApellidoM = evento.getNewValue();
            int posicionUsuario = evento.getTablePosition().getRow();
            evento.getTableView().getItems().get(posicionUsuario).setApellidoM(nuevoApellidoM);
        });

        columna4.setCellFactory(TextFieldTableCell.forTableColumn());
        columna4.setOnEditCommit(evento -> {
            String nuevoDomicilio = evento.getNewValue();
            int posicionUsuario = evento.getTablePosition().getRow();
            evento.getTableView().getItems().get(posicionUsuario).setDomicilio(nuevoDomicilio);
        });

        columna5.setCellFactory(TextFieldTableCell.forTableColumn());
        columna5.setOnEditCommit(evento -> {
            String nuevoGenero = evento.getNewValue();
            int posicionUsuario = evento.getTablePosition().getRow();
            evento.getTableView().getItems().get(posicionUsuario).setGenero(nuevoGenero);
        });

        columna6.setCellFactory(TextFieldTableCell.forTableColumn());
        columna6.setOnEditCommit(evento -> {
            String nuevoCurp = evento.getNewValue();
            int posicionUsuario = evento.getTablePosition().getRow();
            evento.getTableView().getItems().get(posicionUsuario).setCurp(nuevoCurp);
        });

        columna7.setCellFactory(TextFieldTableCell.forTableColumn());
        columna7.setOnEditCommit(evento -> {
            String nuevoNumeroControl = evento.getNewValue();
            int posicionUsuario = evento.getTablePosition().getRow();
            evento.getTableView().getItems().get(posicionUsuario).setNumeroControl(nuevoNumeroControl);
        });

        columna8.setCellFactory(TextFieldTableCell.forTableColumn());
        columna8.setOnEditCommit(evento -> {
            String nuevoCorreo = evento.getNewValue();
            int posicionUsuario = evento.getTablePosition().getRow();
            evento.getTableView().getItems().get(posicionUsuario).setCorreo(nuevoCorreo);
        });

        columna9.setCellFactory(TextFieldTableCell.forTableColumn());
        columna9.setOnEditCommit(evento -> {
            String nuevoCelular = evento.getNewValue();
            int posicionUsuario = evento.getTablePosition().getRow();
            evento.getTableView().getItems().get(posicionUsuario).setCelular(nuevoCelular);
        });

        // Agregar columnas a la tabla
        tableView.getColumns().add(columna1);
        tableView.getColumns().add(columna2);
        tableView.getColumns().add(columna3);
        tableView.getColumns().add(columna4);
        tableView.getColumns().add(columna5);
        tableView.getColumns().add(columna6);
        tableView.getColumns().add(columna7);
        tableView.getColumns().add(columna8);
        tableView.getColumns().add(columna9);


    }
}
