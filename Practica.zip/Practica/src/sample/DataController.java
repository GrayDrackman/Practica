package sample;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;


public class DataController {

    private HashMap<String,Usuario> usuarios = new HashMap<>();

    public DataController() {

    }

    public boolean insertarUsuario(Usuario usuario) {
        if(usuarios.get(usuario.getId()) != null) return false;
        usuarios.put(usuario.getId(), usuario);
        toFile();
        return true;
    }
    public boolean actualizarUsuario(Usuario usuario) {
        if(usuarios.get(usuario.getId()) == null) return false;
        usuarios.put(usuario.getId(), usuario);
        toFile();
        return true;
    }
    public boolean eliminarUsuario(String idUsuario) {
        Usuario u = usuarios.remove(idUsuario);
        toFile();
        return (u != null);
    }
    public Usuario consultarUsuario(String idUsuario) {
        return usuarios.get(idUsuario);
    }

    private boolean toFile(){
        Gson gson = new Gson();
        String json = gson.toJson(usuarios);

        Path path = Paths.get("src/sample/data.txt");
        try {
            Files.write(path, json.getBytes());
            return true;
        } catch (IOException e){
            e.printStackTrace();
        }
        return false;
    }
    public void fromFile(){
        Path path = Paths.get("src/sample/data.txt");
        try {
            String json = Files.readAllLines(path).get(0);
            Gson gson = new Gson();
            Type type = new TypeToken<HashMap<String, Usuario>>(){}.getType();
            HashMap<String, Usuario> usuarios = gson.fromJson(json, type);
            setUsuarios(usuarios);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void setUsuarios(HashMap<String, Usuario> usuarios) {
        this.usuarios = usuarios;
    }
}
