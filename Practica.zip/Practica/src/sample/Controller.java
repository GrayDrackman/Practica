package sample;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import mijavafx.textfield.EmailTextField;
import mijavafx.textfield.MiTextField;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    @FXML
    private TextField txtIdentificador, txtNombre, txtApellidoP, txtApellidoM;
    @FXML
    private MiTextField txtDireccion;
    @FXML
    private EmailTextField txtCorreo;
    @FXML
    private ComboBox<String> cmbGenero;

    private DataController dataController;

    public void btnClickGuardar(ActionEvent actionEvent) {
        String id = txtIdentificador.getText();
        Usuario usuario = new Usuario(id);

        usuario.setNombre(txtNombre.getText());
        usuario.setApellidoP(txtApellidoP.getText());
        usuario.setApellidoM(txtApellidoM.getText());
        usuario.setDomicilio(txtDireccion.getText());
        usuario.setCorreo(txtCorreo.getText());
        usuario.setGenero(cmbGenero.getValue());

        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION);
        alerta.setTitle("Confirmación de registro");
        alerta.setHeaderText("¿Deseas registrar estos datos?");
        alerta.setContentText("Los datos se registrarán cuando de click en Aceptar");
        Optional<ButtonType> resultado = alerta.showAndWait();
        if(resultado.get() == ButtonType.OK){
            registrarUsuario();
            boolean ingresado = dataController.insertarUsuario(usuario);
            if(!ingresado)
                dataController.actualizarUsuario(usuario);
        }else{
            System.out.println("Cancelando el registro ...");
        }
    }

    private void registrarUsuario() {
        String nombre = txtNombre.getText();
        String apellidoP = txtApellidoP.getText();
        String apellidoM = txtApellidoM.getText();
        String domicilio = txtDireccion.getText();
        String email = txtCorreo.getText();
        String numeroControl = txtIdentificador.getText();
        String genero = cmbGenero.getValue();

        String mensaje = "Los datos ingresados son:\n" +
                "No. Control: " + numeroControl + "\n" + nombre + " " + apellidoP + " " + apellidoM +
                " con domicilio en " + domicilio + " " + "\nCorreo electrónico: " + email +
                "\nGénero: " + genero;

        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setContentText(mensaje);
        alerta.setTitle("Confirmación");
        alerta.setHeaderText("Datos registrados");
        alerta.show();
        limpiarFormulario();
    }

    public void onTxtIdChanged(KeyEvent keyEvent) {
        String id = txtIdentificador.getText();
        Usuario usuario = dataController.consultarUsuario(id);
        if(usuario != null) {
            mostrarUsuario(usuario);
        } else {
            limpiarFormulario();
        }
    }

    private void mostrarUsuario(Usuario usuario) {
        txtNombre.setText(usuario.getNombre());
        txtApellidoP.setText(usuario.getApellidoP());
        txtApellidoM.setText(usuario.getApellidoM());
        txtDireccion.setText(usuario.getDomicilio());
        txtCorreo.setText(usuario.getCorreo());
        cmbGenero.setPromptText(usuario.getGenero());
    }

    private void limpiarFormulario() {
        txtNombre.setText("");
        txtApellidoP.setText("");
        txtApellidoM.setText("");
        txtDireccion.setText("");
        txtCorreo.setText("");
        cmbGenero.setPromptText("");
    }

    public void clickComboBoxGenero(ActionEvent actionEvent){
        String genero = cmbGenero.getValue();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        dataController = new DataController();
        dataController.fromFile();

        cmbGenero.setPromptText("Seleccione un género");
        ObservableList<String> list = cmbGenero.getItems();
        list.add("Masculino");
        list.add("Femenino");
        list.add("Reptiliano");
        list.add("Otro");
        cmbGenero.setItems(list);
    }
}

